package test;

import aggregation.thread.ReceiveMethod;

public class GetTest {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("----put test data----");
        PutTest.main(args);
        System.out.println("----get data----");
        System.out.println(ReceiveMethod.get());
        System.out.println("---sleep 13s----");
        Thread.sleep(13000);
        System.out.println(ReceiveMethod.get());
    }
}
