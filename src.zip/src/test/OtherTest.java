package test;

import aggregation.thread.ReceiveMethod;

public class OtherTest {
    public static void main(String[] args) {
        System.out.println(ReceiveMethod.other());
    }
}
