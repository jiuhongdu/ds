package test;

import aggregation.thread.ReceiveMethod;

import java.io.FileInputStream;
import java.net.Socket;

public class PutTest {

    public static void main(String[] args) {
        try (FileInputStream fis = new FileInputStream("data.txt")){
            byte[] buff = new byte[1024 * 1000];
            int length = fis.read(buff);
            String data = new String(buff, 0, length);

            String req = "";
            req += "PUT /atom.xml HTTP/1.1";
            req += "\n";
            req += "User-Agent: ATOMClient/1/0";
            req += "\n";
            req += "Content-Type: XML";
            req += "\n";
            req += "Content-Length:" + data.length();
            req += "\n";
            req += "LamPort:" + System.currentTimeMillis();
            req += "\n";
            req += "\n";
            req += data;
            String put = ReceiveMethod.put(req);
            System.out.println(put);
            System.out.println(ReceiveMethod.maps);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
