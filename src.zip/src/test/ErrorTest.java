package test;

import aggregation.thread.ReceiveMethod;

public class ErrorTest {
    public static void main(String[] args) {
        System.out.println(ReceiveMethod.error());
    }
}
