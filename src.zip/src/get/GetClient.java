package get;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

// The GET client first adds the protocol and request to the first line of the request packet, and the second line configures the version and model of the client
public class GetClient {
    private static String HOST = "localhost";
    private static int PORT = 4567;

// And instantiate Socket to configure IP and configure port number for connection. Finally, request aggregation server through request packet to obtain data.
    public String get() throws IOException {
        Socket socket = new Socket(HOST, PORT);
        InputStream is = socket.getInputStream();
        OutputStream os = socket.getOutputStream();
        String req = "";
        req += "GET / HTTP/1.1";
        req += "\n";
        req += "User-Agent: ATOMClient/1/0";
        req += "\n";
        os.write(req.getBytes());
        os.flush();

        byte[] rb = new byte[102400];
        int len = is.read(rb);
        String resp = new String(rb, 0, len);
        return resp.substring(resp.indexOf("<?xml"));
    }

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < args.length; i++) {
            String[] split = args[i].split("=");
            if (split[0].trim().equals("port")) {
                PORT = Integer.parseInt(split[1].trim());
            }

            if (split[0].trim().equals("host")) {
                HOST = split[1].trim();
            }
        }

        GetClient getClient = new GetClient();
        System.out.println(getClient.get());
    }

}

