// Resource server, use the packaging good tools to see whether correct XML format, is not false is continued to operate, request packet encapsulation,
// PUT agreement, as well as by IO stream for XML encapsulation for string,
// Request PUT, if the request returns TRUE on success, request failures and anomalies are in exception handling block 10 seconds, 10 seconds after the request again.
// Main starts with an infinite loop, and the interval of each execution is 12 seconds.
// If the PUT method is requested and the return is True, it has been requested and succeeded, and the message of Push Success is output in the console
package content;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Logger;

public class ResourceServer {

    public static String DATA_PATH = "data.txt";
    private static String HOST = "localhost";
    private static int PORT = 4567;
    private final static Logger logger = Logger.getLogger("Resource Server");

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < args.length; i++) {
            String[] split = args[i].split("=");
            if (split[0].trim().equals("port")) {
                PORT = Integer.parseInt(split[1].trim());
            }
            if (split[0].trim().equals("data")) {
                DATA_PATH = split[1].trim();
            }

            if (split[0].trim().equals("host")) {
                HOST = split[1].trim();
            }
        }

        ResourceServer resourceServer = new ResourceServer();
        while (true) {
            if (resourceServer.put())
                logger.info("Push success");
            Thread.sleep(1000 * 60*30);//20ms due
        }
    }


    public boolean put() throws Exception {
        try (Socket socket = new Socket(HOST, PORT);
             FileInputStream fis = new FileInputStream(DATA_PATH)) {
            InputStream is = socket.getInputStream();
            OutputStream os = socket.getOutputStream();
            byte[] buff = new byte[1024 * 1000];
            int length = fis.read(buff);
            String data = new String(buff, 0, length);

            String req = "";
            req += "PUT /atom.xml HTTP/1.1";
            req += "\n";
            req += "User-Agent: ATOMClient/1/0";
            req += "\n";
            req += "Content-Type: XML";
            req += "\n";
            req += "Content-Length:" + data.length();
            req += "\n";
            req += "LamPort:" + System.currentTimeMillis();
            req += "\n";
            req += "\n";
            req += data;

            os.write(req.getBytes());
            os.flush();


            byte[] rb = new byte[1024 * 1024];
            int len = is.read(rb);
            String response = new String(rb, 0, len);
            return response.substring(0, response.indexOf("\n")).contains("200");
        } catch (Exception e) {
            Thread.sleep(10000);
            return put();
        }
    }


}
