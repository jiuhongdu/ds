package aggregation.pojo;

public class Entry {
    public String title;
    public String subtitle;
    public String link;
    public String updated;
    public String author;
    public String id;


    @Override
    public String toString() {
        return "Entry{" +
                "title='" + title + '\'' +
                ", subtitle='" + subtitle + '\'' +
                ", link='" + link + '\'' +
                ", updated='" + updated + '\'' +
                ", author='" + author + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
