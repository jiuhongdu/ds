package aggregation.utils;


import aggregation.pojo.Entry;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

public class ResolverXMLAndPutData {

    public static Map<String, Entry> resolverPut(String body) throws Exception {
        String[] entries = body.split("entry");
        HashMap<String, Entry> result = new HashMap<>();
        if (entries.length > 0) {
            for (int i = 0; i < entries.length; i++) {
	System.out.println(entries[i]);
                String[] split = entries[i].trim().split("\n");
                Entry entry = new Entry();
                for (int i1 = 0; i1 < split.length; i1++) {
                    String s = split[i1].trim();
                    String key = s.substring(0, s.indexOf(":"));
                    String value = s.substring(s.indexOf(":") + 1);
                    entry.getClass().getDeclaredField(key).set(entry, value);
                }
                result.put(entry.id, entry);
            }
        }
        return result;
    }


    public static String parseXML(Map<String, Entry> map) throws Exception {
        DocumentBuilderFactory bbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = bbf.newDocumentBuilder();
        Document document = db.newDocument();
        Element feed = document.createElement("feed");
        document.appendChild(feed);
        map.forEach((s, entry) -> {
            Element title = document.createElement("title");
            title.setTextContent(entry.title);
            Element id = document.createElement("id");
            id.setTextContent(entry.id);
            Element author = document.createElement("author");
            author.setTextContent(entry.author);
            Element link = document.createElement("link");
            link.setTextContent(entry.link);
            Element subtitle = document.createElement("subtitle");
            subtitle.setTextContent(entry.subtitle);
            Element updated = document.createElement("updated");
            updated.setTextContent(entry.updated);


            Element node = document.createElement("entry");
            node.appendChild(title);
            node.appendChild(id);
            node.appendChild(author);
            node.appendChild(link);
            node.appendChild(subtitle);
            node.appendChild(updated);
            feed.appendChild(node);
        });
        TransformerFactory tff = TransformerFactory.newInstance();
        Transformer tf = tff.newTransformer();
        tf.setOutputProperty(OutputKeys.INDENT, "yes");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        tf.transform(new DOMSource(document), new StreamResult(byteArrayOutputStream));
        return byteArrayOutputStream.toString();
    }
}
