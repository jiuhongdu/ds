package aggregation.thread;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ReceiveThread implements Runnable {

    private Socket socket;

    public ReceiveThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        String out = null;
        OutputStream os = null;
        try {
            // Get input stream
            InputStream is = socket.getInputStream();
            // Get output stream
            os = socket.getOutputStream();
            // The byte array that receives the data
            byte[] buff = new byte[1024 * 100];
            int length = is.read(buff);
            // Data received
            String req = new String(buff, 0, length);
            // Line protocol
            String protocolLine = req.substring(0, req.indexOf("\n"));
            // GET Protocol
            if (protocolLine.contains("GET"))
                out = ReceiveMethod.get();
                // PUT Protocol
            else if (protocolLine.contains("PUT"))
                out = ReceiveMethod.put(req);
                // Other Protocol
            else
                out = ReceiveMethod.other();
        } catch (Exception e) {
            e.printStackTrace();
            out = ReceiveMethod.error();
        } finally {
            try {
                // Write Data
                os.write(out.getBytes());
                // Flush OutPutStream
                os.flush();
                socket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
