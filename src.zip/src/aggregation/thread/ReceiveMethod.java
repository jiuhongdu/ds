package aggregation.thread;

import aggregation.pojo.Entry;
import aggregation.utils.ResolverXMLAndPutData;

import java.io.FileOutputStream;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ReceiveMethod {
    private static long lamPort = 0;
    private static Lock lock = new ReentrantLock();
    public static Map<String, Entry> maps = new HashMap<>();
    public static Map<String, Entry> old = new HashMap<>();

    private static String header(int status, String contentType, String method) {
        StringBuilder header = new StringBuilder();
        // Protocol Line
        header.append("HTTP/1.1 ").append(status).append(" OK").append("\n");
        header.append("Content-Type").append(":").append(contentType).append("\n");
        header.append("Allow").append(":").append(method).append("\n");
        return String.valueOf(header);
    }


    public static String get() {

        try {
            // lamPort active Execute after 12 seconds
            if (lamPort != 0 && System.currentTimeMillis() - lamPort > 12000) {
                maps.forEach((s, entry) -> {
                    old.put(s, entry);
                });
                lamPort = 0;
                try (FileOutputStream fos = new FileOutputStream("backup.txt")) {
                    lock.lock();
                    StringBuilder sb = new StringBuilder();
                    maps.forEach((s, entry) -> {
                        sb.append("id").append(":").append(entry.id).append("\n");
                        sb.append("updated").append(":").append(entry.updated).append("\n");
                        sb.append("author").append(":").append(entry.author).append("\n");
                        sb.append("link").append(":").append(entry.link).append("\n");
                        sb.append("subtitle").append(":").append(entry.subtitle).append("\n");
                        sb.append("title").append(":").append(entry.title).append("\n");
                        sb.append("entry\n");
                    });
                    sb.delete(sb.lastIndexOf("entry"), sb.length());
                    fos.write(sb.toString().getBytes());
                    fos.flush();
                } finally {
                    lock.unlock();
                }
            }

            //  Header
            String header = header(200, "XML", "GET");
            String body = ResolverXMLAndPutData.parseXML(old);
            // Out Data
            return header + "\n" + body;
        } catch (Exception e) {
            e.printStackTrace();
            return header(500, "XML", "GET");
        }

    }


    public static String put(String req) {
        try {
            String data = req.substring(req.indexOf("\n\n")).trim();
            long mill = 0;
            String[] lines = req.split("\n");
            for (int i = 1; i < lines.length; i++) {
                String[] header = lines[i].split(":");
                if (header.length == 2) {
                    if (header[0].trim().equals("LamPort")) {
                        mill = Long.valueOf(header[1]);
                    }
                }
            }
            if (mill != 0) {
                try {
                    lock.lock();
                    if (lamPort < mill) {
                        lamPort = mill;
                        Map<String, Entry> resolver = ResolverXMLAndPutData.resolverPut(data);
                        resolver.forEach((s, entry) -> {
                            entry.updated = new Date().toString();
                            maps.put(s, entry);
                        });
                    }
                } finally {
                    lock.unlock();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                lock.lock();
                old.forEach((s, entry) -> {
                    maps.put(s, entry);
                });
            } finally {
                lock.unlock();
            }

            return header(500, "STATUS", "PUT");
        }

        return header(200, "STATUS", "PUT");
    }

    public static String other() {
        return header(400, "STATUS", "OTHER");
    }

    public static String error() {
        return header(500, "STATUS", "ERROR");
    }
}
