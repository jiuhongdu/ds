package aggregation;

import aggregation.pojo.Entry;
import aggregation.thread.ReceiveMethod;
import aggregation.thread.ReceiveThread;
import aggregation.utils.ResolverXMLAndPutData;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

//Aggregate the startup class of the server, 
//instantiate a ServerSocket, 
//listen on the port of 4567, 
//use the Accept method of ServerSocket to block to get the connected socket object, 
//and then start a processing thread for processing.
public class AggregationServer {
    public static String DATA_PATH = "backup.txt";
    public static Integer PORT = 4567;

    private static void recover() {
        try (FileInputStream fis = new FileInputStream(DATA_PATH)) {
            byte[] buff = new byte[1024 * 1024];
            int len = fis.read(buff);
            String s = new String(buff, 0, len);
            Map<String, Entry> map = ResolverXMLAndPutData.resolverPut(s);
            ReceiveMethod.maps=map;
            ReceiveMethod.old=map;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Aggregate the startup class of the server, instantiate a ServerSocket, listen on the port of 4567, use the Accept method of ServerSocket to block to get the connected socket object, and then start a processing thread for processing.
    public static void main(String[] args) throws IOException {

        for (int i = 0; i < args.length; i++) {
            String[] split = args[i].split("=");
            if (split[0].trim().equals("port")) {
                PORT = Integer.parseInt(split[1].trim());
            }
            if (split[0].trim().equals("backup")) {
                DATA_PATH = split[1].trim();
            }
        }


        recover();
        ServerSocket serverSocket = new ServerSocket(PORT);
        for (; ; ) {
            try {
                Socket client = serverSocket.accept();
                ReceiveThread receiveThread = new ReceiveThread(client);
                Thread thread = new Thread(receiveThread);
                thread.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
